package com.mphasis.laboratory.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Technicain")
public class Technician {
	@Id
	private Integer technicianId;
	private String technicianFirstName;
	private String technicianLastName;
	private String technicianEmailId;
	private Integer technicianPhoneNumber;
	
	public Technician() {}

	public Technician(Integer technicianId, String technicianFirstName, String technicianLastName,
			String technicianEmailId, Integer technicianPhoneNumber) {
		super();
		this.technicianId = technicianId;
		this.technicianFirstName = technicianFirstName;
		this.technicianLastName = technicianLastName;
		this.technicianEmailId = technicianEmailId;
		this.technicianPhoneNumber = technicianPhoneNumber;
	}

	public Integer getTechnicianId() {
		return technicianId;
	}

	public void setTechnicianId(Integer technicianId) {
		this.technicianId = technicianId;
	}

	public String getTechnicianFirstName() {
		return technicianFirstName;
	}

	public void setTechnicianFirstName(String technicianFirstName) {
		this.technicianFirstName = technicianFirstName;
	}

	public String getTechnicianLastName() {
		return technicianLastName;
	}

	public void setTechnicianLastName(String technicianLastName) {
		this.technicianLastName = technicianLastName;
	}

	public String getTechnicianEmailId() {
		return technicianEmailId;
	}

	public void setTechnicianEmailId(String technicianEmailId) {
		this.technicianEmailId = technicianEmailId;
	}

	public Integer getTechnicianPhoneNumber() {
		return technicianPhoneNumber;
	}

	public void setTechnicianPhoneNumber(Integer technicianPhoneNumber) {
		this.technicianPhoneNumber = technicianPhoneNumber;
	}

	@Override
	public String toString() {
		return "Technician [technicianId=" + technicianId + ", technicianFirstName=" + technicianFirstName
				+ ", technicianLastName=" + technicianLastName + ", technicianEmailId=" + technicianEmailId
				+ ", technicianPhoneNumber=" + technicianPhoneNumber + "]";
	}
	
	
	
	

}
