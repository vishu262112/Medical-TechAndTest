package com.mphasis.laboratory.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MedicalTest")
public class MedicalTest {
	
	@Id
	private Integer testId;
	private String testName;
	private Integer price;
	private String category;
	
	public MedicalTest() {}

	public MedicalTest(Integer testId, String testName, Integer price, String category) {
		super();
		this.testId = testId;
		this.testName = testName;
		this.price = price;
		this.category = category;
	}

	public Integer getTestId() {
		return testId;
	}

	public void setTestId(Integer testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "MedicalTest [testId=" + testId + ", testName=" + testName + ", price=" + price + ", category="
				+ category + "]";
	}
	
	

}
