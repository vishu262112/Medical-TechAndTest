package com.mphasis.laboratory.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.laboratory.entity.Technician;
import com.mphasis.laboratory.repository.TechnicianRepository;

@Component("ts")
public class TechnicianService {
	
	@Autowired
	private TechnicianRepository technicianRepo;
	
	public Technician create(Technician technician)
	{
		return technicianRepo.save(technician);
	}
	
	public List<Technician> read()
	{
		return technicianRepo.findAll();
	}
	

	public Technician read(String technicianId)
	{
		return technicianRepo.findById("technicianId").get();
	}
	
	public Technician update(Technician technician)
	{
		return technicianRepo.save(technician);
	}
	
	public void delete(String technicianId)
	{
		technicianRepo.delete(read(technicianId));
	}
	

}
