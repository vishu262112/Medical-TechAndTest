package com.mphasis.laboratory.service;

public class DoctorService {

}
